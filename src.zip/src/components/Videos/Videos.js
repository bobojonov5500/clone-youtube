import React from "react";
import { Grid2, Container } from "@mui/material";
import VideoCard from "./Video-card";

const Videos = ({ data, error, isError, isLoading }) => {
  if (isError) {
    return <h3>{error.message}</h3>;
  }

  return (
    <Container
      maxWidth={false}
      disableGutters
      sx={{ maxWidth: "1920px", padding: 0, border: "1px red solid" }}
    >
      <Grid2
        container
        spacing={2}
        columns={{ xs: 6, sm: 6, md: 12, lg: 12, xl: 15 }}
      >
        {data?.items.map((item, index) => (
          <Grid2
            key={index}
            xs={6} // 1 ta
            sm={4} // 2 ta
            md={4} // 3 ta
            lg={3} // 4 ta
            xl={3} // 15/3 = 5 ta
            sx={{ display: "flex" }}
          >
            <VideoCard item={item} />
          </Grid2>
        ))}
      </Grid2>
    </Container>
  );
};

export default Videos;
